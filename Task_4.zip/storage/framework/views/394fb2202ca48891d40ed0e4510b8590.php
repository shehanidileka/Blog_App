

<?php $__env->startSection('title', 'Activity Log · Admin'); ?>

<?php $__env->startSection('panel'); ?>
<div class="mb-4">
    <h3 class="fw-bold mb-1">Activity Log</h3>
    <p class="muted mb-0">See who did what, and when.</p>
</div>

<div class="card-x p-3 p-md-4 mb-4">
    <form method="GET" action="<?php echo e(route('admin.activity.index')); ?>" class="row g-2 align-items-end">
        <div class="col-md-4">
            <label class="form-label small mb-1" for="q">Search</label>
            <input type="text" id="q" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="User, text or IP...">
        </div>
        <div class="col-md-2">
            <label class="form-label small mb-1" for="type">Type</label>
            <select id="type" name="type" class="form-select">
                <option value="">All</option>
                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($t); ?>" <?php if(request('type') === $t): echo 'selected'; endif; ?>><?php echo e(ucfirst($t)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-2">
            <label class="form-label small mb-1" for="from">From</label>
            <input type="date" id="from" name="from" value="<?php echo e(request('from')); ?>" class="form-control">
        </div>
        <div class="col-md-2">
            <label class="form-label small mb-1" for="to">To</label>
            <input type="date" id="to" name="to" value="<?php echo e(request('to')); ?>" class="form-control">
        </div>
        <div class="col-md-2 d-flex gap-2">
            <button class="btn btn-dash flex-grow-1"><i class="bi bi-funnel"></i></button>
            <?php if(request()->hasAny(['q','type','from','to'])): ?>
                <a href="<?php echo e(route('admin.activity.index')); ?>" class="btn btn-nav-outline">Clear</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<div class="card-x p-3 p-md-4">
    <div class="table-responsive">
        <table class="table table-x table-hover align-middle mb-0">
            <thead><tr><th>When</th><th>User</th><th>Action</th><th>Details</th><th>IP</th></tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-nowrap">
                            <div><?php echo e($log->created_at->format('M d, Y')); ?></div>
                            <small class="muted"><?php echo e($log->created_at->format('H:i:s')); ?></small>
                        </td>
                        <td><?php echo e($log->user_name ?? 'Guest / system'); ?></td>
                        <td><span class="badge text-bg-<?php echo e($log->tone); ?>"><?php echo e(str_replace(['.', '_'], ' ', $log->action)); ?></span></td>
                        <td style="min-width:260px">
                            <?php echo e($log->description); ?>

                            <?php if($log->properties): ?>
                                <details class="mt-1">
                                    <summary class="small muted" style="cursor:pointer">Changes</summary>
                                    <ul class="small mb-0 mt-1 ps-3">
                                        <?php $__currentLoopData = $log->properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <b><?php echo e($field); ?></b>:
                                                <span class="muted"><?php echo e($v['old'] ?? '—'); ?></span> → <?php echo e($v['new'] ?? '—'); ?>

                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </details>
                            <?php endif; ?>
                        </td>
                        <td class="muted small text-nowrap"><?php echo e($log->ip_address ?? '—'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="text-center muted py-4">No activity found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-3"><?php echo e($logs->links()); ?></div>
</div>

<div class="card-x p-3 p-md-4 mt-4">
    <form method="POST" action="<?php echo e(route('admin.activity.prune')); ?>" class="d-flex flex-wrap align-items-center gap-2"
          onsubmit="return confirm('Delete the old log entries? This cannot be undone.')">
        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
        <span class="muted small">Delete entries older than</span>
        <input type="number" name="days" value="90" min="1" max="3650" class="form-control form-control-sm" style="width:90px">
        <span class="muted small">days</span>
        <button class="btn btn-nav-outline btn-sm"><i class="bi bi-trash me-1"></i>Clean up</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\ServerClub\Task_4\resources\views/admin/activity.blade.php ENDPATH**/ ?>