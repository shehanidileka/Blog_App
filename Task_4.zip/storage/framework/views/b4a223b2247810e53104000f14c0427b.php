

<?php $__env->startSection('title', 'Roles & Permissions · Admin'); ?>

<?php $__env->startSection('panel'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
    <div>
        <h3 class="fw-bold mb-1">Roles & Permissions</h3>
        <p class="muted mb-0">Control what each role is allowed to do.</p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('admin.permissions.index')); ?>" class="btn btn-nav-outline"><i class="bi bi-key me-1"></i>Manage permissions</a>
        <a href="<?php echo e(route('admin.roles.create')); ?>" class="btn btn-dash"><i class="bi bi-plus-lg me-1"></i>New role</a>
    </div>
</div>

<div class="card-x p-3 p-md-4">
    <div class="table-responsive">
        <table class="table table-x table-hover align-middle mb-0">
            <thead>
                <tr><th>Role</th><th>Users</th><th>Permissions</th><th class="text-end">Actions</th></tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div class="fw-semibold">
                                <?php echo e($role->name); ?>

                                <?php if($role->is_system): ?>
                                    <span class="role-badge user ms-1">System</span>
                                <?php endif; ?>
                            </div>
                            <small class="muted"><?php echo e($role->description); ?></small>
                        </td>
                        <td class="muted"><?php echo e($role->users_count); ?></td>
                        <td class="muted"><?php echo e($role->slug === 'admin' ? 'All' : $role->permissions_count); ?></td>
                        <td class="text-end text-nowrap">
                            <a href="<?php echo e(route('admin.roles.edit', $role)); ?>" class="btn-icon"
                               title="<?php echo e($role->slug === 'admin' ? 'View' : 'Edit'); ?>">
                                <i class="bi <?php echo e($role->slug === 'admin' ? 'bi-eye' : 'bi-pencil'); ?>"></i>
                            </a>
                            <?php if(! $role->is_system): ?>
                                <form method="POST" action="<?php echo e(route('admin.roles.destroy', $role)); ?>" class="d-inline"
                                      onsubmit="return confirm('Delete this role?')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="btn-icon danger" title="Delete"><i class="bi bi-trash"></i></button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\ServerClub\Task_4\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>