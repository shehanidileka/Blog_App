

<?php $__env->startSection('title', 'Admin Panel · MyBlog'); ?>

<?php $__env->startSection('panel'); ?>
<div class="mb-4">
    <h3 class="fw-bold mb-1">Admin Overview</h3>
    <p class="muted mb-0">Everything happening on MyBlog.</p>
</div>

<div class="row g-3 mb-4">
    <div class="col-6 col-xl-3">
        <div class="card-x stat"><div class="stat-icon"><i class="bi bi-people"></i></div>
            <div><div class="stat-num"><?php echo e($stats['users']); ?></div><small class="muted">Users</small></div></div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="card-x stat"><div class="stat-icon"><i class="bi bi-file-earmark-text"></i></div>
            <div><div class="stat-num"><?php echo e($stats['posts']); ?></div><small class="muted">Published posts</small></div></div>
    </div>
    <div class="col-6 col-xl-3">
        <a href="<?php echo e(route('admin.posts.index', ['status' => 'pending'])); ?>" class="card-x stat text-decoration-none" style="color:inherit">
            <div class="stat-icon" style="background:#f59e0b"><i class="bi bi-hourglass-split"></i></div>
            <div><div class="stat-num"><?php echo e($stats['pending']); ?></div><small class="muted">Pending approval</small></div>
        </a>
    </div>
    <div class="col-6 col-xl-3">
        <div class="card-x stat"><div class="stat-icon"><i class="bi bi-eye"></i></div>
            <div><div class="stat-num"><?php echo e(number_format($stats['views'])); ?></div><small class="muted">Views</small></div></div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-lg-7">
        <div class="card-x p-4 h-100">
            <h6 class="mb-3"><i class="bi bi-bar-chart me-2 text-primary"></i>Published posts by category</h6>
            <?php $__currentLoopData = $byCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mb-3">
                    <div class="d-flex justify-content-between small mb-1">
                        <span><?php echo e($c->name); ?></span><span class="muted"><?php echo e($c->posts_count); ?></span>
                    </div>
                    <div class="bar"><span style="width: <?php echo e(($c->posts_count / $max) * 100); ?>%"></span></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="card-x p-4 h-100">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h6 class="mb-0"><i class="bi bi-person-plus me-2 text-primary"></i>New users</h6>
                <a href="<?php echo e(route('admin.users.index')); ?>" class="small text-decoration-none">View all</a>
            </div>
            <?php $__currentLoopData = $latestUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex align-items-center gap-3 py-2" style="border-top:1px solid var(--border)">
                    <?php if($u->avatar): ?>
                        <img src="<?php echo e($u->avatar); ?>" class="avatar" alt="" referrerpolicy="no-referrer">
                    <?php else: ?>
                        <span class="avatar"><?php echo e(strtoupper(substr($u->name, 0, 1))); ?></span>
                    <?php endif; ?>
                    <div style="min-width:0">
                        <div class="small fw-semibold text-truncate"><?php echo e($u->name); ?></div>
                        <small class="muted"><?php echo e($u->created_at->diffForHumans()); ?></small>
                    </div>
                    <span class="role-badge <?php echo e($u->role); ?> ms-auto"><?php echo e($u->role); ?></span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<div class="card-x p-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 class="mb-0"><i class="bi bi-clock-history me-2 text-primary"></i>Latest posts</h6>
        <a href="<?php echo e(route('admin.posts.index')); ?>" class="small text-decoration-none">View all</a>
    </div>
    <div class="table-responsive">
        <table class="table table-x align-middle mb-0">
            <thead><tr><th>Post</th><th>Author</th><th>Category</th><th>Status</th><th>Date</th></tr></thead>
            <tbody>
                <?php $__currentLoopData = $latestPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $badge = ['pending' => 'warning', 'approved' => 'success', 'rejected' => 'danger'][$p->status] ?? 'secondary'; ?>
                    <tr>
                        <td class="fw-semibold"><?php echo e(Str::limit($p->title, 40)); ?></td>
                        <td class="muted"><?php echo e($p->user->name); ?></td>
                        <td><span class="badge-cat"><?php echo e($p->category->name); ?></span></td>
                        <td><span class="badge text-bg-<?php echo e($badge); ?>"><?php echo e(ucfirst($p->status)); ?></span></td>
                        <td class="muted"><?php echo e($p->created_at->format('M d, Y')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\ServerClub\Task_4\resources\views/admin/index.blade.php ENDPATH**/ ?>