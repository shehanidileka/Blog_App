

<?php $__env->startSection('title', ($role->exists ? 'Edit Role' : 'New Role') . ' · Admin'); ?>

<?php $__env->startSection('panel'); ?>
<?php $locked = $role->exists && $role->slug === 'admin'; ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold mb-1"><?php echo e($role->exists ? ($locked ? 'View Role' : 'Edit Role') : 'New Role'); ?></h3>
        <p class="muted mb-0">Choose what this role is allowed to do.</p>
    </div>
    <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn btn-nav-outline btn-sm"><i class="bi bi-arrow-left me-1"></i>Back</a>
</div>

<?php if($locked): ?>
    <div class="alert alert-info rounded-3 py-2 small">
        <i class="bi bi-lock me-1"></i>The Admin role always has full access and cannot be changed.
    </div>
<?php endif; ?>

<form method="POST" action="<?php echo e($role->exists ? route('admin.roles.update', $role) : route('admin.roles.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if($role->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

    <div class="card-x p-4 mb-4">
        <div class="row g-3">
            <div class="col-md-5">
                <label class="form-label" for="name">Role name</label>
                <input type="text" id="name" name="name" class="form-control" required maxlength="50"
                       placeholder="e.g. Editor" value="<?php echo e(old('name', $role->name)); ?>" <?php echo e($locked ? 'readonly' : ''); ?>>
            </div>
            <div class="col-md-7">
                <label class="form-label" for="description">Description</label>
                <input type="text" id="description" name="description" class="form-control" maxlength="255"
                       placeholder="What is this role for?" value="<?php echo e(old('description', $role->description)); ?>" <?php echo e($locked ? 'readonly' : ''); ?>>
            </div>
        </div>
    </div>

    <div class="row g-3">
        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $perms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6">
                <div class="card-x p-4 h-100">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h6 class="mb-0"><?php echo e($group); ?></h6>
                        <?php if (! ($locked)): ?>
                            <a href="#" class="small" data-toggle-group>Select all / none</a>
                        <?php endif; ?>
                    </div>

                    <?php $__currentLoopData = $perms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check form-switch mb-3">
                            <input class="form-check-input" type="checkbox" role="switch" name="permissions[]"
                                   value="<?php echo e($p->id); ?>" id="perm<?php echo e($p->id); ?>"
                                   <?php echo e($locked || in_array($p->id, old('permissions', $selected)) ? 'checked' : ''); ?>

                                   <?php echo e($locked ? 'disabled' : ''); ?>>
                            <label class="form-check-label" for="perm<?php echo e($p->id); ?>">
                                <span class="fw-semibold"><?php echo e($p->name); ?></span>
                                <span class="d-block muted small"><?php echo e($p->description); ?></span>
                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php if (! ($locked)): ?>
        <div class="mt-4 d-flex gap-2">
            <button type="submit" class="btn btn-dash px-4"><?php echo e($role->exists ? 'Update Role' : 'Create Role'); ?></button>
            <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn btn-nav-outline">Cancel</a>
        </div>
    <?php endif; ?>
</form>

<script>
    document.querySelectorAll('[data-toggle-group]').forEach(function (link) {
        link.addEventListener('click', function (e) {
            e.preventDefault();
            var boxes = link.closest('.card-x').querySelectorAll('input[type=checkbox]');
            var allOn = Array.from(boxes).every(function (b) { return b.checked; });
            boxes.forEach(function (b) { b.checked = !allOn; });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\ServerClub\Task_4\resources\views/admin/roles/form.blade.php ENDPATH**/ ?>