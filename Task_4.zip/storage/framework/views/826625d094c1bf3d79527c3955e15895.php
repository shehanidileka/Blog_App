

<?php $__env->startSection('title', 'My Posts · MyBlog'); ?>

<?php $__env->startSection('panel'); ?>

<?php $first = \Illuminate\Support\Str::before(auth()->user()->name, ' '); ?>


<div class="dash-hero mb-4">
    <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
        <div>
            <h3 class="mb-1">Hi <?php echo e($first); ?> 👋</h3>
            <p>Manage your stories, track views and publish something new.</p>
        </div>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts.create')): ?>
            <a href="<?php echo e(route('dashboard.posts.create')); ?>" class="btn btn-new"><i class="bi bi-plus-circle me-1"></i>New post</a>
        <?php endif; ?>
    </div>
</div>


<div class="row g-3 mb-4">
    <div class="col-sm-4 stat-card-col">
        <div class="card-x stat stat-card">
            <div class="stat-icon"><i class="bi bi-journal-richtext"></i></div>
            <div><div class="stat-num"><?php echo e(number_format($stats['posts'])); ?></div><small class="muted">My posts</small></div>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="card-x stat stat-card">
            <div class="stat-icon" style="background:linear-gradient(135deg,#f59e0b,#f97316)"><i class="bi bi-eye"></i></div>
            <div><div class="stat-num"><?php echo e(number_format($stats['views'])); ?></div><small class="muted">Total views</small></div>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="card-x stat stat-card">
            <div class="stat-icon" style="background:linear-gradient(135deg,#8b5cf6,#6366f1)"><i class="bi bi-grid"></i></div>
            <div><div class="stat-num"><?php echo e(number_format($stats['categories'])); ?></div><small class="muted">Categories used</small></div>
        </div>
    </div>
</div>


<div class="card-x p-3 p-md-4">
    <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
        <h5 class="fw-bold mb-0">My Posts</h5>
        <span class="muted small"><?php echo e($posts->total()); ?> <?php echo e(\Illuminate\Support\Str::plural('post', $posts->total())); ?></span>
    </div>

    
    <div class="d-flex flex-wrap gap-2 mb-3">
        <a href="<?php echo e(route('dashboard', request()->only('q'))); ?>" class="chip <?php echo e(! request('category') ? 'active' : ''); ?>">All<small><?php echo e($stats['posts']); ?></small></a>
        <?php $__currentLoopData = $categories->where('my_posts_count', '>', 0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('dashboard', array_filter(['category' => $c->id, 'q' => request('q')]))); ?>"
               class="chip <?php echo e((string) request('category') === (string) $c->id ? 'active' : ''); ?>"><?php echo e($c->name); ?><small><?php echo e($c->my_posts_count); ?></small></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <form method="GET" action="<?php echo e(route('dashboard')); ?>" class="row g-2 mb-4">
        <?php if(request('category')): ?>
            <input type="hidden" name="category" value="<?php echo e(request('category')); ?>">
        <?php endif; ?>
        <div class="col-md-9">
            <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Search my posts by title...">
        </div>
        <div class="col-md-3 d-flex gap-2">
            <button class="btn btn-dash flex-fill"><i class="bi bi-search me-1"></i>Search</button>
            <?php if(request()->hasAny(['q', 'category'])): ?>
                <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-nav-outline" title="Clear"><i class="bi bi-x-lg"></i></a>
            <?php endif; ?>
        </div>
    </form>

    <div class="table-responsive">
        <table class="table table-x table-hover align-middle mb-0">
            <thead>
                <tr><th>Post</th><th>Category</th><th>Status</th><th>Views</th><th class="text-end">Actions</th></tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $badge = ['pending' => 'warning', 'approved' => 'success', 'rejected' => 'danger', 'draft' => 'secondary'][$post->status] ?? 'secondary';
                    ?>
                    <tr class="post-row">
                        <td>
                            <div class="d-flex align-items-center gap-3">
                                <div class="row-thumb" <?php if($post->image): ?> style="background-image:url('<?php echo e($post->image_url); ?>')" <?php endif; ?>></div>
                                <div style="min-width:0">
                                    <?php if($post->status === 'approved'): ?>
                                        <a href="<?php echo e(route('posts.show', $post)); ?>" class="ptitle"><?php echo e(\Illuminate\Support\Str::limit($post->title, 45)); ?></a>
                                    <?php else: ?>
                                        <span class="ptitle"><?php echo e(\Illuminate\Support\Str::limit($post->title, 45)); ?></span>
                                    <?php endif; ?>
                                    <div><small class="muted"><?php echo e($post->created_at->format('M d, Y')); ?></small></div>
                                </div>
                            </div>
                        </td>
                        <td><span class="badge-cat"><?php echo e($post->category->name ?? '—'); ?></span></td>
                        <td>
                            <span class="badge text-bg-<?php echo e($badge); ?>"><?php echo e(ucfirst($post->status)); ?></span>
                            <?php if($post->status === 'rejected' && $post->rejection_reason): ?>
                                <div class="small muted mt-1" title="<?php echo e($post->rejection_reason); ?>"><?php echo e(\Illuminate\Support\Str::limit($post->rejection_reason, 32)); ?></div>
                            <?php endif; ?>
                        </td>
                        <td class="muted"><?php echo e(number_format($post->views)); ?></td>
                        <td class="text-end text-nowrap">
                            <?php if($post->status === 'approved'): ?>
                                <a href="<?php echo e(route('posts.show', $post)); ?>" class="btn-icon" title="View" target="_blank"><i class="bi bi-eye"></i></a>
                            <?php endif; ?>
                            <a href="<?php echo e(route('dashboard.posts.edit', $post)); ?>" class="btn-icon" title="Edit"><i class="bi bi-pencil"></i></a>
                            <form method="POST" action="<?php echo e(route('dashboard.posts.destroy', $post)); ?>" class="d-inline"
                                  onsubmit="return confirm('Delete this post? This cannot be undone.')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="btn-icon danger" title="Delete"><i class="bi bi-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5">
                            <div class="empty-state">
                                <div class="ico"><i class="bi bi-pencil-square"></i></div>
                                <?php if(request()->hasAny(['q', 'category'])): ?>
                                    <h6 class="fw-bold">No matching posts</h6>
                                    <p class="muted small mb-3">Try a different search or clear the filters.</p>
                                    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-nav-outline">Clear filters</a>
                                <?php else: ?>
                                    <h6 class="fw-bold">You haven't written anything yet</h6>
                                    <p class="muted small mb-3">Share your first story with the community.</p>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts.create')): ?>
                                        <a href="<?php echo e(route('dashboard.posts.create')); ?>" class="btn btn-dash"><i class="bi bi-plus-circle me-1"></i>Write your first post</a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if($posts->hasPages()): ?>
        <div class="mt-4 d-flex justify-content-center"><?php echo e($posts->links()); ?></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\ServerClub\Task_4\resources\views/dashboard/index.blade.php ENDPATH**/ ?>