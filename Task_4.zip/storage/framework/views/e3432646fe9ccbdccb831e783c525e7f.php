

<?php $__env->startSection('title', $post->seo_title . ' · MyBlog'); ?>

<?php $__env->startPush('meta'); ?>
    <meta name="description" content="<?php echo e($post->seo_description); ?>">
    <?php if($post->meta_keywords): ?>
        <meta name="keywords" content="<?php echo e($post->meta_keywords); ?>">
    <?php endif; ?>
    <link rel="canonical" href="<?php echo e(route('posts.show', $post)); ?>">

    
    <meta property="og:type" content="article">
    <meta property="og:site_name" content="MyBlog">
    <meta property="og:title" content="<?php echo e($post->seo_title); ?>">
    <meta property="og:description" content="<?php echo e($post->seo_description); ?>">
    <meta property="og:url" content="<?php echo e(route('posts.show', $post)); ?>">
    <?php if($post->seo_image): ?>
        <meta property="og:image" content="<?php echo e($post->seo_image); ?>">
    <?php endif; ?>

    
    <meta name="twitter:card" content="<?php echo e($post->seo_image ? 'summary_large_image' : 'summary'); ?>">
    <meta name="twitter:title" content="<?php echo e($post->seo_title); ?>">
    <meta name="twitter:description" content="<?php echo e($post->seo_description); ?>">
    <?php if($post->seo_image): ?>
        <meta name="twitter:image" content="<?php echo e($post->seo_image); ?>">
    <?php endif; ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<?php
    $mins   = max(1, ceil(str_word_count(strip_tags($post->body)) / 200));
    $url    = urlencode(route('posts.show', $post));
    $ttl    = urlencode($post->title);
    $rc     = $reactionCounts->sum();
    $author = $post->user;
?>

<div class="post-wrap">

    <?php if(! $post->isApproved()): ?>
        <div class="alert alert-warning rounded-3">
            <i class="bi bi-hourglass-split me-1"></i>
            This post is <strong><?php echo e($post->status); ?></strong> and is not visible to the public.
        </div>
    <?php endif; ?>

    
    <nav class="crumbs reveal" aria-label="breadcrumb">
        <a href="<?php echo e(route('home')); ?>"><i class="bi bi-house me-1"></i>Home</a>
        <i class="bi bi-chevron-right sep"></i>
        <a href="<?php echo e(route('categories.show', $post->category->slug)); ?>"><?php echo e($post->category->name); ?></a>
        <i class="bi bi-chevron-right sep"></i>
        <span class="cur"><?php echo e($post->title); ?></span>
    </nav>

    
    <header class="post-head reveal">
        <a href="<?php echo e(route('categories.show', $post->category->slug)); ?>" class="post-cat">
            <i class="bi bi-hash"></i><?php echo e($post->category->name); ?>

        </a>

        <h1 class="post-title"><?php echo e($post->title); ?></h1>

        <?php if($post->excerpt): ?>
            <p class="post-lead"><?php echo e($post->excerpt); ?></p>
        <?php endif; ?>

        <div class="byline-row">
            <div class="by-author">
                <?php if($author->avatar): ?>
                    <img src="<?php echo e($author->avatar); ?>" alt="" referrerpolicy="no-referrer">
                <?php else: ?>
                    <span class="avatar"><?php echo e(strtoupper(substr($author->name, 0, 1))); ?></span>
                <?php endif; ?>
                <div>
                    <b><?php echo e($author->name); ?></b>
                    <small><?php echo e($post->created_at->format('M d, Y')); ?> · <?php echo e($mins); ?> min read</small>
                </div>
            </div>

            <div class="by-stats">
                <span class="by-stat"><i class="bi bi-eye"></i><?php echo e(number_format($post->views)); ?> <?php echo e(Str::plural('view', $post->views)); ?></span>
                <a href="#reactions" class="by-stat"><i class="bi bi-heart"></i><?php echo e($rc); ?></a>
                <a href="#comments" class="by-stat"><i class="bi bi-chat-dots"></i><?php echo e($comments->count()); ?></a>
            </div>
        </div>
    </header>

    
    <?php if($post->image): ?>
        <figure class="post-cover reveal">
            <img src="<?php echo e(asset('storage/'.$post->image)); ?>" alt="<?php echo e($post->image_alt ?: $post->title); ?>">
        </figure>
    <?php endif; ?>

    <div class="row g-4 g-xl-5">

        
        <div class="col-lg-8">

            <article class="card-x article-card reveal">
                <div class="post-body" id="postBody">
                    <?php echo $post->body_html; ?>

                </div>

                <?php if($post->tags->isNotEmpty()): ?>
                    <div class="d-flex flex-wrap align-items-center gap-2 mt-5 pt-4" style="border-top:1px solid var(--border)">
                        <i class="bi bi-tags muted me-1"></i>
                        <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('tags.show', $t->slug)); ?>" class="post-tag">#<?php echo e($t->name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </article>

            <?php if(session('success')): ?>
                <div class="alert alert-success rounded-4 mt-3 mb-0"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            
            <div class="card-x react-card mt-4 reveal" id="reactions">
                <h5>Enjoyed this article?</h5>
                <small class="muted">Let <?php echo e(Str::before($author->name, ' ')); ?> know what you think.</small>

                <div class="react-row">
                    <?php $__currentLoopData = \App\Models\Reaction::TYPES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $emoji): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $active = $myReaction === $type; ?>
                        <?php if(auth()->guard()->check()): ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reactions.create')): ?>
                                <form method="POST" action="<?php echo e(route('posts.react', $post)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="type" value="<?php echo e($type); ?>">
                                    <button type="submit" class="btn react-btn <?php echo e($active ? 'btn-dash' : 'btn-nav-outline'); ?>" title="<?php echo e(ucfirst($type)); ?>">
                                        <span class="emo"><?php echo e($emoji); ?></span>
                                        <span class="fw-semibold"><?php echo e($reactionCounts[$type] ?? 0); ?></span>
                                    </button>
                                </form>
                            <?php else: ?>
                                <span class="btn react-btn btn-nav-outline disabled" title="You don't have permission to react">
                                    <span class="emo"><?php echo e($emoji); ?></span>
                                    <span class="fw-semibold"><?php echo e($reactionCounts[$type] ?? 0); ?></span>
                                </span>
                            <?php endif; ?>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="btn react-btn btn-nav-outline" title="Login to react">
                                <span class="emo"><?php echo e($emoji); ?></span>
                                <span class="fw-semibold"><?php echo e($reactionCounts[$type] ?? 0); ?></span>
                            </a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <?php if(auth()->guard()->guest()): ?>
                    <small class="muted d-block mt-3"><a href="<?php echo e(route('login')); ?>">Login</a> to react to this post.</small>
                <?php endif; ?>
            </div>

            
            <div class="card-x cm-card mt-4 reveal" id="comments">
                <div class="cm-head">
                    <h5><i class="bi bi-chat-dots"></i>Comments <span class="cm-count"><?php echo e($comments->count()); ?></span></h5>
                </div>

                <?php if($post->allow_comments): ?>
                    <?php if(auth()->guard()->check()): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('comments.create')): ?>
                            <form method="POST" action="<?php echo e(route('comments.store', $post)); ?>" class="cm-form">
                                <?php echo csrf_field(); ?>
                                <?php if(auth()->user()->avatar): ?>
                                    <img src="<?php echo e(auth()->user()->avatar); ?>" alt="" referrerpolicy="no-referrer">
                                <?php else: ?>
                                    <span class="avatar"><?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?></span>
                                <?php endif; ?>
                                <div class="box">
                                    <textarea name="body" id="cmBody" rows="3" maxlength="1000" placeholder="Share your thoughts..."
                                              class="<?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('body')); ?></textarea>
                                    <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div class="foot">
                                        <small><span id="cmCount">0</span> / 1000</small>
                                        <button type="submit" class="btn btn-dash btn-sm px-4"><i class="bi bi-send me-1"></i>Post comment</button>
                                    </div>
                                </div>
                            </form>
                        <?php else: ?>
                            <div class="cm-note"><i class="bi bi-lock"></i>You don't have permission to write comments.</div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="cm-note">
                            <i class="bi bi-person-circle"></i>
                            <span><a href="<?php echo e(route('login')); ?>" class="fw-semibold">Login</a> or <a href="<?php echo e(route('register')); ?>" class="fw-semibold">register</a> to join the conversation.</span>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="cm-note"><i class="bi bi-chat-square-x"></i>Comments are turned off for this post.</div>
                <?php endif; ?>

                <?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="cm-item">
                        <?php if($comment->user->avatar): ?>
                            <img src="<?php echo e($comment->user->avatar); ?>" class="avatar" alt="" referrerpolicy="no-referrer">
                        <?php else: ?>
                            <span class="avatar"><?php echo e(strtoupper(substr($comment->user->name, 0, 1))); ?></span>
                        <?php endif; ?>
                        <div class="cm-bubble">
                            <div class="cm-meta">
                                <strong><?php echo e($comment->user->name); ?></strong>
                                <?php if($comment->user_id === $post->user_id): ?>
                                    <span class="badge-cat">Author</span>
                                <?php endif; ?>
                                <small><?php echo e($comment->created_at->diffForHumans()); ?></small>
                                <?php if(auth()->guard()->check()): ?>
                                    <?php if(auth()->id() === $comment->user_id || auth()->user()->can('comments.delete_any')): ?>
                                        <form method="POST" action="<?php echo e(route('comments.destroy', $comment)); ?>" class="ms-auto"
                                              onsubmit="return confirm('Delete this comment?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="cm-del" title="Delete"><i class="bi bi-trash"></i></button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <div class="cm-text"><?php echo nl2br(e($comment->body)); ?></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="empty-cm">
                        <i class="bi bi-chat-heart"></i>
                        No comments yet.<?php if($post->allow_comments): ?> Be the first to comment!<?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        
        <div class="col-lg-4">
            <aside class="post-aside">

                <div class="card-x aside-card author-card reveal">
                    <div class="big-av">
                        <?php if($author->avatar): ?>
                            <img src="<?php echo e($author->avatar); ?>" alt="" referrerpolicy="no-referrer">
                        <?php else: ?>
                            <?php echo e(strtoupper(substr($author->name, 0, 1))); ?>

                        <?php endif; ?>
                    </div>
                    <div class="muted small text-uppercase" style="letter-spacing:.1em;font-size:.68rem;font-weight:700">Written by</div>
                    <div class="nm"><?php echo e($author->name); ?></div>
                    <?php if($author->bio): ?>
                        <p class="bio"><?php echo e($author->bio); ?></p>
                    <?php endif; ?>
                    <span class="cnt"><i class="bi bi-journal-richtext"></i><?php echo e($author->posts()->approved()->count()); ?> published <?php echo e(Str::plural('post', $author->posts()->approved()->count())); ?></span>
                    <?php if($author->website): ?>
                        <div class="mt-2">
                            <a href="<?php echo e($author->website); ?>" target="_blank" rel="noopener noreferrer" class="small fw-semibold text-decoration-none">
                                <i class="bi bi-link-45deg"></i><?php echo e(parse_url($author->website, PHP_URL_HOST) ?: $author->website); ?>

                            </a>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="card-x aside-card toc reveal" id="toc">
                    <h6 class="aside-title"><i class="bi bi-list-ul"></i>In this article</h6>
                    <ol id="tocList"></ol>
                </div>

                <div class="card-x aside-card reveal">
                    <h6 class="aside-title"><i class="bi bi-share"></i>Share this post</h6>
                    <div class="share-row">
                        <a class="share-btn wa" target="_blank" rel="noopener" title="WhatsApp" href="https://wa.me/?text=<?php echo e($ttl); ?>%20<?php echo e($url); ?>"><i class="bi bi-whatsapp"></i></a>
                        <a class="share-btn fb" target="_blank" rel="noopener" title="Facebook" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e($url); ?>"><i class="bi bi-facebook"></i></a>
                        <a class="share-btn tw" target="_blank" rel="noopener" title="X" href="https://twitter.com/intent/tweet?text=<?php echo e($ttl); ?>&url=<?php echo e($url); ?>"><i class="bi bi-twitter-x"></i></a>
                        <button type="button" class="share-btn cp" id="copyLink" title="Copy link"><i class="bi bi-link-45deg"></i></button>
                    </div>
                </div>

            </aside>
        </div>
    </div>

    
    <?php if($related->count()): ?>
        <div class="rel-head">
            <h3>More in <?php echo e($post->category->name); ?></h3>
            <a href="<?php echo e(route('categories.show', $post->category->slug)); ?>">View all <i class="bi bi-arrow-right"></i></a>
        </div>
        <div class="row g-4">
            <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-lg-4 reveal">
                    <a href="<?php echo e(route('posts.show', $r)); ?>" class="card-x post-card rel-card spot d-block text-decoration-none" style="color:inherit">
                        <div class="post-img" <?php if($r->image): ?> style="background-image:url('<?php echo e(asset('storage/'.$r->image)); ?>')" <?php endif; ?>></div>
                        <div class="p-3">
                            <h6 class="mb-2"><?php echo e($r->title); ?></h6>
                            <small class="muted"><i class="bi bi-clock me-1"></i><?php echo e($r->created_at->diffForHumans()); ?></small>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>

<script>
(function () {
    // Table of contents from h2 / h3 inside the article
    const heads = [...document.querySelectorAll('#postBody h2, #postBody h3')];
    const toc = document.getElementById('toc'), list = document.getElementById('tocList');

    if (heads.length >= 2) {
        heads.forEach((h, i) => {
            if (!h.id) h.id = 'sec-' + (i + 1);
            const li = document.createElement('li');
            if (h.tagName === 'H3') li.className = 'sub';
            li.innerHTML = '<a href="#' + h.id + '"></a>';
            li.firstChild.textContent = h.textContent;
            list.appendChild(li);
        });
        toc.classList.add('show');

        const items = [...list.children];
        const spy = new IntersectionObserver((entries) => {
            entries.forEach(en => {
                if (en.isIntersecting) {
                    const idx = heads.indexOf(en.target);
                    items.forEach((li, i) => li.classList.toggle('active', i === idx));
                }
            });
        }, { rootMargin: '-90px 0px -70% 0px' });
        heads.forEach(h => spy.observe(h));
    }

    // Copy link
    const cp = document.getElementById('copyLink');
    cp.addEventListener('click', async () => {
        try {
            await navigator.clipboard.writeText(location.href.split('#')[0]);
            cp.classList.add('done');
            cp.innerHTML = '<i class="bi bi-check2"></i>';
            setTimeout(() => { cp.classList.remove('done'); cp.innerHTML = '<i class="bi bi-link-45deg"></i>'; }, 1800);
        } catch (e) { prompt('Copy this link:', location.href); }
    });

    // Comment counter
    const cm = document.getElementById('cmBody'), cc = document.getElementById('cmCount');
    if (cm) { const u = () => cc.textContent = cm.value.length; cm.addEventListener('input', u); u(); }
})();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\ServerClub\Task_4\resources\views/posts/show.blade.php ENDPATH**/ ?>