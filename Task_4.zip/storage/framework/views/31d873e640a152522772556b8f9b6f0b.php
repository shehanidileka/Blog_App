

<?php $__env->startSection('title', 'SMTP test'); ?>
<?php $__env->startSection('tagline', 'Email settings check'); ?>

<?php $__env->startSection('content'); ?>
  <h2 style="margin:0 0 12px;font-size:22px;color:#1f2340;">Hello <?php echo e($recipientName); ?> 👋</h2>

  <p style="margin:0 0 20px;">
    Great news! Your <strong style="color:#6a679c;">SMTP settings are working</strong>.
    This is a test email sent from <strong><?php echo e(config('app.name')); ?></strong>.
  </p>

  <?php if(count($details)): ?>
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0"
           style="background:#f4f5ff;border-radius:12px;margin:0 0 24px;">
      <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td style="padding:10px 16px;font-size:13px;color:#6b6f93;width:40%;"><?php echo e($label); ?></td>
          <td style="padding:10px 16px;font-size:13px;font-weight:700;color:#1f2340;"><?php echo e($value); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  <?php endif; ?>

  <table role="presentation" cellpadding="0" cellspacing="0" align="center">
    <tr>
      <td align="center" bgcolor="#6a679c" style="border-radius:10px;">
        <a href="<?php echo e(url('/')); ?>"
           style="display:inline-block;padding:14px 30px;font-size:15px;font-weight:700;color:#ffffff;text-decoration:none;border-radius:10px;background:#6a679c;">
          Open <?php echo e(config('app.name')); ?>

        </a>
      </td>
    </tr>
  </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('emails.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\ServerClub\Task_4\resources\views/emails/test.blade.php ENDPATH**/ ?>