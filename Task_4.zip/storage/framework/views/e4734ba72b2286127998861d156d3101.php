

<?php $__env->startSection('title', 'Permissions · Admin'); ?>

<?php $__env->startSection('panel'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
    <div>
        <h3 class="fw-bold mb-1">Permissions</h3>
        <p class="muted mb-0">Add, edit or delete permissions, then give them to roles.</p>
    </div>
    <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn btn-nav-outline"><i class="bi bi-shield-check me-1"></i>Roles</a>
</div>


<div class="card-x p-4 mb-4">
    <h6 class="mb-3">New permission</h6>
    <form method="POST" action="<?php echo e(route('admin.permissions.store')); ?>" class="row g-3">
        <?php echo csrf_field(); ?>
        <div class="col-md-4">
            <label class="form-label" for="p-name">Name</label>
            <input type="text" id="p-name" name="name" class="form-control" required maxlength="80"
                   placeholder="e.g. Publish posts" value="<?php echo e(old('name')); ?>">
        </div>
        <div class="col-md-4">
            <label class="form-label" for="p-slug">Slug</label>
            <input type="text" id="p-slug" name="slug" class="form-control" required maxlength="80"
                   placeholder="e.g. posts.publish" value="<?php echo e(old('slug')); ?>">
        </div>
        <div class="col-md-4">
            <label class="form-label" for="p-group">Group</label>
            <input type="text" id="p-group" name="group" class="form-control" required maxlength="50" list="groupList"
                   placeholder="e.g. Posts" value="<?php echo e(old('group')); ?>">
            <datalist id="groupList">
                <?php $__currentLoopData = $allGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($g); ?>"><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </datalist>
        </div>
        <div class="col-12">
            <label class="form-label" for="p-desc">Description</label>
            <input type="text" id="p-desc" name="description" class="form-control" maxlength="255"
                   placeholder="What does this permission allow?" value="<?php echo e(old('description')); ?>">
        </div>
        <div class="col-12">
            <button class="btn btn-dash"><i class="bi bi-plus-lg me-1"></i>Add permission</button>
        </div>
    </form>
    <p class="muted small mt-3 mb-0">
        Use it in code with <code>@can('slug')</code> or <code>middleware('can:slug')</code>.
        A new permission has no effect until you tick it for a role.
    </p>
</div>


<?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $perms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card-x p-3 p-md-4 mb-4">
        <h6 class="mb-3"><?php echo e($group); ?></h6>
        <div class="table-responsive">
            <table class="table table-x align-middle mb-0">
                <thead><tr><th>Permission</th><th>Slug</th><th>Roles</th><th class="text-end">Actions</th></tr></thead>
                <tbody>
                    <?php $__currentLoopData = $perms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $locked = in_array($p->slug, $builtIn, true); ?>
                        <tr>
                            <td>
                                <div class="fw-semibold">
                                    <?php echo e($p->name); ?>

                                    <?php if($locked): ?><span class="role-badge user ms-1">Built-in</span><?php endif; ?>
                                </div>
                                <small class="muted"><?php echo e($p->description); ?></small>
                            </td>
                            <td><code><?php echo e($p->slug); ?></code></td>
                            <td class="muted"><?php echo e($p->roles_count); ?></td>
                            <td class="text-end text-nowrap">
                                <button type="button" class="btn-icon" title="Edit"
                                        data-bs-toggle="modal" data-bs-target="#editPerm"
                                        data-action="<?php echo e(route('admin.permissions.update', $p)); ?>"
                                        data-name="<?php echo e($p->name); ?>" data-slug="<?php echo e($p->slug); ?>"
                                        data-group="<?php echo e($p->group); ?>" data-description="<?php echo e($p->description); ?>"
                                        data-locked="<?php echo e($locked ? 1 : 0); ?>">
                                    <i class="bi bi-pencil"></i>
                                </button>
                                <?php if (! ($locked)): ?>
                                    <form method="POST" action="<?php echo e(route('admin.permissions.destroy', $p)); ?>" class="d-inline"
                                          onsubmit="return confirm('Delete this permission? It will be removed from all roles.')">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button class="btn-icon danger" title="Delete"><i class="bi bi-trash"></i></button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<div class="modal fade" id="editPerm" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form method="POST" class="modal-content card-x" id="editPermForm">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title">Edit permission</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label" for="e-name">Name</label>
                    <input type="text" id="e-name" name="name" class="form-control" required maxlength="80">
                </div>
                <div class="mb-3">
                    <label class="form-label" for="e-slug">Slug</label>
                    <input type="text" id="e-slug" name="slug" class="form-control" required maxlength="80">
                    <div class="muted small mt-1 d-none" id="e-slug-note">Built-in slugs are used by the application and cannot be changed.</div>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="e-group">Group</label>
                    <input type="text" id="e-group" name="group" class="form-control" required maxlength="50" list="groupList">
                </div>
                <div>
                    <label class="form-label" for="e-desc">Description</label>
                    <input type="text" id="e-desc" name="description" class="form-control" maxlength="255">
                </div>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-nav-outline" data-bs-dismiss="modal">Cancel</button>
                <button class="btn btn-dash">Save</button>
            </div>
        </form>
    </div>
</div>

<script>
    document.getElementById('editPerm').addEventListener('show.bs.modal', function (e) {
        var b = e.relatedTarget, f = document.getElementById('editPermForm');
        var locked = b.dataset.locked === '1';
        f.action = b.dataset.action;
        document.getElementById('e-name').value  = b.dataset.name;
        document.getElementById('e-group').value = b.dataset.group;
        document.getElementById('e-desc').value  = b.dataset.description || '';
        var slug = document.getElementById('e-slug');
        slug.value = b.dataset.slug;
        slug.disabled = locked;               // disabled fields are not submitted; the server ignores slug for built-ins
        document.getElementById('e-slug-note').classList.toggle('d-none', !locked);
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\ServerClub\Task_4\resources\views/admin/permissions.blade.php ENDPATH**/ ?>