
<nav class="navbar navbar-expand-lg topbar sticky-top" id="topbar">
    <div class="container">
        <?php if (isset($component)) { $__componentOriginal987d96ec78ed1cf75b349e2e5981978f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal987d96ec78ed1cf75b349e2e5981978f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal987d96ec78ed1cf75b349e2e5981978f)): ?>
<?php $attributes = $__attributesOriginal987d96ec78ed1cf75b349e2e5981978f; ?>
<?php unset($__attributesOriginal987d96ec78ed1cf75b349e2e5981978f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal987d96ec78ed1cf75b349e2e5981978f)): ?>
<?php $component = $__componentOriginal987d96ec78ed1cf75b349e2e5981978f; ?>
<?php unset($__componentOriginal987d96ec78ed1cf75b349e2e5981978f); ?>
<?php endif; ?>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="nav">
            <ul class="navbar-nav ms-lg-4 gap-lg-1">
                <li class="nav-item">
                    <a class="nav-link nav-link-x <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">
                        <i class="bi bi-house me-1"></i>Home
                    </a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link nav-link-x dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        <i class="bi bi-grid me-1"></i>Categories
                    </a>
                    <ul class="dropdown-menu" style="min-width:220px">
                        <li><a class="dropdown-item" href="<?php echo e(route('posts.index')); ?>"><i class="bi bi-collection me-2"></i>All Posts</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <?php $__empty_1 = true; $__currentLoopData = $navCategories ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li><a class="dropdown-item" href="<?php echo e(route('categories.show', $c->slug)); ?>"><i class="bi bi-folder me-2"></i><?php echo e($c->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li><span class="dropdown-item-text muted">No categories yet</span></li>
                        <?php endif; ?>
                    </ul>
                </li>
            </ul>

            <form class="search-box mx-lg-auto my-3 my-lg-0" action="<?php echo e(route('posts.index')); ?>" method="GET">
                <i class="bi bi-search s-icon"></i>
                <input type="text" name="q" id="searchInput" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Search posts..." autocomplete="off">
                <kbd class="d-none d-lg-inline">/</kbd>
            </form>

            <div class="d-flex flex-wrap align-items-center gap-2">
                <button id="themeBtn" class="icon-btn" title="Toggle theme">
                    <i class="bi bi-sun icon-sun"></i><i class="bi bi-moon-stars icon-moon"></i>
                </button>

                <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-nav-outline">Login</a>
                    <a href="<?php echo e(route('register')); ?>" class="btn btn-dash">Register</a>
                <?php endif; ?>

                <?php if(auth()->guard()->check()): ?>
                    
                    <div class="dropdown">
                        <button type="button" class="icon-btn position-relative" data-bs-toggle="dropdown" title="Notifications" aria-label="Notifications">
                            <i class="bi bi-bell"></i>
                            <?php if(($unreadCount ?? 0) > 0): ?>
                                <span class="notif-dot"><?php echo e($unreadCount > 9 ? '9+' : $unreadCount); ?></span>
                            <?php endif; ?>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end p-0" style="width:340px;max-width:92vw">
                            <div class="d-flex justify-content-between align-items-center px-3 py-2 border-bottom" style="border-color:var(--border)!important">
                                <strong class="small">Notifications</strong>
                                <?php if(($unreadCount ?? 0) > 0): ?>
                                    <form method="POST" action="<?php echo e(route('notifications.readAll')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-link btn-sm p-0 text-decoration-none">Mark all read</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                            <?php $__empty_1 = true; $__currentLoopData = $navNotifications ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <a href="<?php echo e(route('notifications.open', $n->id)); ?>" class="notif-item <?php echo e($n->read_at ? '' : 'unread'); ?>">
                                    <?php if(($n->data['status'] ?? '') === 'approved'): ?>
                                        <i class="bi bi-check-circle-fill text-success"></i>
                                    <?php else: ?>
                                        <i class="bi bi-x-circle-fill text-danger"></i>
                                    <?php endif; ?>
                                    <div>
                                        <div class="small"><?php echo e($n->data['message'] ?? 'Notification'); ?></div>
                                        <small class="muted"><?php echo e($n->created_at->diffForHumans()); ?></small>
                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="text-center muted small py-4">No notifications yet</div>
                            <?php endif; ?>
                            <a href="<?php echo e(route('notifications.index')); ?>" class="d-block text-center small fw-semibold py-2 text-decoration-none border-top" style="border-color:var(--border)!important">View all</a>
                        </div>
                    </div>

                    
                    <div class="dropdown">
                        <a href="#" class="profile-btn d-flex align-items-center gap-2 text-decoration-none" data-bs-toggle="dropdown">
                            <?php if(auth()->user()->avatar): ?>
                                <img src="<?php echo e(auth()->user()->avatar); ?>" class="avatar" alt="" referrerpolicy="no-referrer">
                            <?php else: ?>
                                <span class="avatar"><?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?></span>
                            <?php endif; ?>
                            <span class="d-none d-xl-inline"><?php echo e(Str::before(auth()->user()->name, ' ')); ?></span>
                            <i class="bi bi-chevron-down small me-1"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" style="min-width:240px">
                            <li class="px-3 py-2">
                                <div class="fw-semibold"><?php echo e(auth()->user()->name); ?></div>
                                <small class="muted"><?php echo e(auth()->user()->email); ?></small>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>"><i class="bi bi-person me-2"></i>My Profile</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('dashboard')); ?>"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a></li>
                            <?php if(auth()->user()->can('admin.access')): ?>
                                <li><a class="dropdown-item" href="<?php echo e(route('admin.dashboard')); ?>"><i class="bi bi-shield-lock me-2"></i>Admin Panel</a></li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <form method="POST" action="<?php echo e(route('logout')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item text-danger">
                                        <i class="bi bi-box-arrow-right me-2"></i>Logout
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav><?php /**PATH E:\laragon\www\ServerClub\Task_4\resources\views/partials/navbar.blade.php ENDPATH**/ ?>