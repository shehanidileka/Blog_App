
<footer class="footer pt-5 pb-3">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-4">
                <?php if (isset($component)) { $__componentOriginal987d96ec78ed1cf75b349e2e5981978f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal987d96ec78ed1cf75b349e2e5981978f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal987d96ec78ed1cf75b349e2e5981978f)): ?>
<?php $attributes = $__attributesOriginal987d96ec78ed1cf75b349e2e5981978f; ?>
<?php unset($__attributesOriginal987d96ec78ed1cf75b349e2e5981978f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal987d96ec78ed1cf75b349e2e5981978f)): ?>
<?php $component = $__componentOriginal987d96ec78ed1cf75b349e2e5981978f; ?>
<?php unset($__componentOriginal987d96ec78ed1cf75b349e2e5981978f); ?>
<?php endif; ?>
                <p class="muted small mt-3">Stories, tutorials and recipes shared with love.</p>
                <div class="social">
                    <a href="https://www.facebook.com/Shehani De Silva" target="_blank" rel="noopener noreferrer" class="s-facebook" aria-label="Facebook" title="Facebook">
                        <i class="bi bi-facebook"></i>
                    </a>
                    <a href="https://www.linkedin.com/in/shehani-de-silva-91bb69370/" target="_blank" rel="noopener noreferrer" class="s-linkedin" aria-label="LinkedIn" title="LinkedIn">
                        <i class="bi bi-linkedin"></i>
                    </a>
                    <a href="https://wa.me/94753779823?text=Hello%20MyBlog" target="_blank" rel="noopener noreferrer" class="s-whatsapp" aria-label="WhatsApp" title="WhatsApp">
                        <i class="bi bi-whatsapp"></i>
                    </a>
                    <a href="https://github.com/shehanidileka" target="_blank" rel="noopener noreferrer" class="s-github" aria-label="GitHub" title="GitHub">
                        <i class="bi bi-github"></i>
                    </a>
                </div>
            </div>

            <div class="col-6 col-md-2">
                <h6>Quick Links</h6>
                <ul class="list-unstyled small">
                    <li class="mb-1"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <?php if(auth()->guard()->guest()): ?>
                        <li class="mb-1"><a href="<?php echo e(route('login')); ?>">Login</a></li>
                        <li class="mb-1"><a href="<?php echo e(route('register')); ?>">Register</a></li>
                    <?php endif; ?>
                    <li class="mb-1"><a href="#">Contact</a></li>
                </ul>
            </div>

            <div class="col-6 col-md-3">
                <h6>Categories</h6>
                <ul class="list-unstyled small">
                    <?php $__currentLoopData = ($navCategories ?? collect())->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="mb-1"><a href="<?php echo e(route('categories.show', $c->slug)); ?>"><?php echo e($c->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <div class="col-md-3">
                <h6>Join us</h6>
                <p class="muted small">Register and write your own posts.</p>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-dash"><i class="bi bi-speedometer2 me-1"></i>My Dashboard</a>
                <?php else: ?>
                    <a href="<?php echo e(route('register')); ?>" class="btn btn-dash">Register</a>
                <?php endif; ?>
            </div>
        </div>

        <hr style="border-color: var(--border)">
        <p class="text-center muted small mb-0">© <?php echo e(date('Y')); ?> MyBlog. All rights reserved.</p>
    </div>
</footer><?php /**PATH E:\laragon\www\ServerClub\Task_4\resources\views/partials/footer.blade.php ENDPATH**/ ?>