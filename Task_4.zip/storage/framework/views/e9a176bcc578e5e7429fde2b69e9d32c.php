

<?php $__env->startSection('title', 'Weekly summary'); ?>
<?php $__env->startSection('tagline', $periodFrom->format('M d') . ' – ' . $periodTo->format('M d, Y')); ?>

<?php $__env->startSection('content'); ?>
  <h2 style="margin:0 0 12px;font-size:22px;color:#1f2340;">Hi <?php echo e($adminName); ?> 👋</h2>
  <p style="margin:0 0 24px;">Here is what happened on <strong><?php echo e(config('app.name')); ?></strong> this week.</p>

  
  <?php
    $cards = [
      'New posts'     => $stats['posts'],
      'New comments'  => $stats['comments'],
      'New reactions' => $stats['reactions'],
      'New users'     => $stats['users'],
    ];
  ?>

  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 24px;">
    <?php $__currentLoopData = array_chunk($cards, 2, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php $diff = $s['value'] - $s['prev']; ?>
          <td width="50%" style="padding:6px;">
            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f5ff;border-radius:12px;">
              <tr>
                <td style="padding:16px;">
                  <div style="font-size:12px;color:#6b6f93;"><?php echo e($label); ?></div>
                  <div style="font-size:30px;font-weight:700;color:#1f2340;line-height:1.2;"><?php echo e($s['value']); ?></div>
                  <div style="font-size:12px;color:<?php echo e($diff > 0 ? '#16a34a' : ($diff < 0 ? '#dc2626' : '#8a8fb0')); ?>;">
                    <?php if($diff > 0): ?> ▲ +<?php echo e($diff); ?> <?php elseif($diff < 0): ?> ▼ <?php echo e($diff); ?> <?php else: ?> – no change <?php endif; ?>
                    vs last week
                  </div>
                </td>
              </tr>
            </table>
          </td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>

  <p style="margin:0 0 24px;font-size:13px;color:#6b6f93;">
    Total views on all posts: <strong style="color:#1f2340;"><?php echo e(number_format($stats['views'])); ?></strong>
  </p>

  
  <?php if($stats['pending'] > 0): ?>
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#fff7e6;border-radius:12px;margin:0 0 24px;">
      <tr>
        <td style="padding:14px 16px;font-size:14px;color:#8a5a00;">
          ⏳ <strong><?php echo e($stats['pending']); ?></strong> <?php echo e(\Illuminate\Support\Str::plural('post', $stats['pending'])); ?> waiting for your approval.
        </td>
      </tr>
    </table>
  <?php endif; ?>

  
  <h3 style="margin:0 0 10px;font-size:16px;color:#1f2340;">Top posts this week</h3>

  <?php $__empty_1 = true; $__currentLoopData = $topPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 8px;border-bottom:1px solid #eceefa;">
      <tr>
        <td width="32" valign="top" style="padding:8px 0;font-size:18px;font-weight:700;color:#6a679c;"><?php echo e($i + 1); ?></td>
        <td style="padding:8px 0;">
          <a href="<?php echo e(route('posts.show', $post)); ?>" style="color:#1f2340;font-weight:700;text-decoration:none;font-size:14px;"><?php echo e($post->title); ?></a>
          <div style="font-size:12px;color:#8a8fb0;">
            by <?php echo e($post->user?->name ?? 'Unknown'); ?> · <?php echo e($post->week_comments); ?> comments · <?php echo e($post->week_reactions); ?> reactions
          </div>
        </td>
      </tr>
    </table>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p style="margin:0 0 8px;font-size:14px;color:#8a8fb0;">No comments or reactions this week.</p>
  <?php endif; ?>

  
  <table role="presentation" cellpadding="0" cellspacing="0" align="center" style="margin-top:24px;">
    <tr>
      <td align="center" bgcolor="#6a679c" style="border-radius:10px;">
        <a href="<?php echo e(route('admin.dashboard')); ?>"
           style="display:inline-block;padding:14px 30px;font-size:15px;font-weight:700;color:#ffffff;text-decoration:none;border-radius:10px;background:#6a679c;">
          Open admin panel
        </a>
      </td>
    </tr>
  </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('emails.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laragon\www\ServerClub\Task_4\resources\views/emails/weekly-summary.blade.php ENDPATH**/ ?>