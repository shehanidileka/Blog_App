
<aside class="card-x p-3 panel-side">
    <div class="d-flex align-items-center gap-3 p-2 mb-1">
        <?php if(auth()->user()->avatar): ?>
            <img src="<?php echo e(auth()->user()->avatar); ?>" class="avatar" alt="" referrerpolicy="no-referrer">
        <?php else: ?>
            <span class="avatar"><?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?></span>
        <?php endif; ?>
        <div style="min-width:0">
            <div class="fw-semibold text-truncate"><?php echo e(auth()->user()->name); ?></div>
            <small class="muted d-block text-truncate"><?php echo e(auth()->user()->email); ?></small>
        </div>
    </div>

    <?php if(request()->routeIs('admin.*')): ?>
        
        <div class="side-label">Admin</div>
        <a class="side-link <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('admin.dashboard')); ?>"><i class="bi bi-speedometer2"></i>Overview</a>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts.manage')): ?>
            <?php $pendingCount = \App\Models\Post::pending()->count(); ?>

            <a class="side-link <?php echo e(request()->routeIs('admin.posts.*') && request('status') !== 'pending' ? 'active' : ''); ?>" href="<?php echo e(route('admin.posts.index')); ?>"><i class="bi bi-file-earmark-text"></i>All Posts</a>

            <a class="side-link <?php echo e(request()->routeIs('admin.posts.*') && request('status') === 'pending' ? 'active' : ''); ?>" href="<?php echo e(route('admin.posts.index', ['status' => 'pending'])); ?>">
                <i class="bi bi-hourglass-split"></i>Pending Approval
                <?php if($pendingCount > 0): ?>
                    <span class="badge text-bg-warning ms-auto"><?php echo e($pendingCount); ?></span>
                <?php endif; ?>
            </a>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('categories.manage')): ?>
            <a class="side-link <?php echo e(request()->routeIs('admin.categories.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.categories.index')); ?>"><i class="bi bi-tags"></i>Categories</a>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.manage')): ?>
            <a class="side-link <?php echo e(request()->routeIs('admin.users.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.users.index')); ?>"><i class="bi bi-people"></i>Users</a>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.manage')): ?>
            <a class="side-link <?php echo e(request()->routeIs('admin.roles.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.roles.index')); ?>"><i class="bi bi-shield-check"></i>Roles & Permissions</a>
            <a class="side-link <?php echo e(request()->routeIs('admin.permissions.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.permissions.index')); ?>"><i class="bi bi-key"></i>Permissions</a>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('activity.view')): ?>
            <a class="side-link <?php echo e(request()->routeIs('admin.activity.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.activity.index')); ?>"><i class="bi bi-clock-history"></i>Activity Log</a>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings.manage')): ?>
            <a class="side-link <?php echo e(request()->routeIs('admin.settings.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.settings.mail')); ?>"><i class="bi bi-envelope-at"></i>Mail Settings</a>
        <?php endif; ?>

        <div class="side-label">Account</div>
        <a class="side-link <?php echo e(request()->routeIs('profile.*') ? 'active' : ''); ?>" href="<?php echo e(route('profile.edit')); ?>"><i class="bi bi-person-circle"></i>My Profile</a>
        <a class="side-link" href="<?php echo e(route('dashboard')); ?>"><i class="bi bi-person-workspace"></i>My Dashboard</a>
    <?php else: ?>
        
        <div class="side-label">Menu</div>
        <a class="side-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>"><i class="bi bi-grid-1x2"></i>My Posts</a>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts.create')): ?>
            <a class="side-link <?php echo e(request()->routeIs('dashboard.posts.create') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard.posts.create')); ?>"><i class="bi bi-plus-circle"></i>New Post</a>
        <?php endif; ?>

        <a class="side-link <?php echo e(request()->routeIs('profile.*') ? 'active' : ''); ?>" href="<?php echo e(route('profile.edit')); ?>"><i class="bi bi-person-circle"></i>My Profile</a>

        <?php $unreadNotifs = auth()->user()->unreadNotifications()->count(); ?>
        <a class="side-link <?php echo e(request()->routeIs('notifications.*') ? 'active' : ''); ?>" href="<?php echo e(route('notifications.index')); ?>">
            <i class="bi bi-bell"></i>Notifications
            <?php if($unreadNotifs > 0): ?>
                <span class="badge text-bg-danger ms-auto"><?php echo e($unreadNotifs); ?></span>
            <?php endif; ?>
        </a>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.access')): ?>
            <div class="side-label">Admin</div>
            <a class="side-link" href="<?php echo e(route('admin.dashboard')); ?>"><i class="bi bi-shield-lock"></i>Admin Panel</a>
        <?php endif; ?>
        <div class="side-label">Account</div>
    <?php endif; ?>

    <a class="side-link" href="<?php echo e(route('home')); ?>"><i class="bi bi-house"></i>Back to site</a>
    <form method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit" class="side-link danger"><i class="bi bi-box-arrow-right"></i>Logout</button>
    </form>
</aside><?php /**PATH E:\laragon\www\ServerClub\Task_4\resources\views/partials/panel-sidebar.blade.php ENDPATH**/ ?>